const Discord = require("discord.js");

module.exports = {
  config: {
    nombre: "",
    alias: []
  },
  run: async (client, message, args, lang, queue) => {
    
  }
}