const Discord = require("discord.js")
const { Canvas, createCanvas, loadImage } = require("canvas")

module.exports = {
  config: {
    nombre: "typeracer",
    alias: []
  },
  run: async (client, message, args, lang) => {
    let usuario = message.mentions.users.first()
    if(!usuario) return message.channel.send("Menciona al usuario con el cuál jugarás!")
    
    let msg1 = await message.channel.send(new Discord.MessageEmbed()
                        .setDescription(`¿<@${usuario.id}> Aceptas jugar con <@${message.author.id}>?`)
                        .setColor("GREEN"))
    const collector = msg1.channel.createMessageCollector(m => m.author.id === usuario.id && m.channel.id === message.channel.id, {time : 120000})

    let palabrasxd = ["Jugar con fútbol es muy divertido", "El caballo es inteligente", "La otra noche fuimos al cine", "Me gusta comer palomitas", "Me gusta patear el balon", "Quisiera trabajar en ese lugar", "No a la tala de arboles", "Me gusta comer manzanas", "Si un perdedor hace muchos esfuerzos quizas pueda sobrepasar el\npoder de un guerrero distinguido"]
    
    collector.on("collect", async collected => {
    if (collected.content.toLowerCase() === "si"){
              collector.stop()
        let count = 3
      let msg2 = await message.channel.send(new Discord.MessageEmbed()
                          .setDescription(`El juego empieza en ${count} segundos`)
                          .setColor("GREEN"))
            let intervalxd = await setInterval(async function() {
              count -= 1
              msg2.edit(new Discord.MessageEmbed()
                          .setDescription(`El juego empieza en ${count} segundos`)
                          .setColor("GREEN"))
              if(count === 0){
                let random = palabrasxd[Math.floor(palabrasxd.length * Math.random())];
        clearInterval(intervalxd)
                
    const canvas = createCanvas(700, 85)
    const ctx = canvas.getContext("2d");
    ctx.font = "20px bold Arial"
    ctx.fillStyle = "#AFB6B1";
    ctx.fillText(`${random}`, 0, 25);
                
    const attachment = new Discord.MessageAttachment(canvas.toBuffer(), "typeracer.png");

msg2.delete()
        message.channel.send(new Discord.MessageEmbed()
                            .setDescription(`La primera palabra es:`)
                          .attachFiles(attachment)
                          .setImage("attachment://typeracer.png")
                            .setColor("GREEN")
                            .setFooter("El primero en escribir la palabra gana")).then(adivinanzaxd => {
              
               const collector2 = adivinanzaxd.channel.createMessageCollector(m =>  (message.author.id === m.author.id || usuario.id === m.author.id) && m.channel.id === message.channel.id, {time : 600000});
                collector2.on("collect", async collected => {
                  if(collected.content === random){
                    collector2.stop()
                    message.channel.send(`${collected.author.tag} Has Acertado!`)
                  }
                  })
        })
              }
    }, 1000)
    } else if (collected.content.toLowerCase() === "no"){
              collector.stop()
      message.channel.send(new Discord.MessageEmbed()
                          .setDescription("Juego cancelado")
                          .setColor("RED"))
    }
})
collector.on("end", async collected => {
    if (collected.size === 0) return message.channel.send("El usuario tardo mucho en responder!");  
      })
  }
}