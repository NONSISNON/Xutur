module.exports = {
  config: {
    nombre: "xp",
    alias: ["rank"]
  },
  run: async (client, message, args, lang) => {
    const member =
      message.mentions.members.first() ||
      client.users.resolve(args[0]) ||
      message.member;

    const { createCanvas, loadImage } = require("canvas");
    const { MessageAttachment } = require("discord.js");
    const { join } = require("path");
    const db = require("megadb");
    const color = new db.crearDB('color', 'level')
    const level_db = new db.crearDB("levels", "level");
    let estado = {online :'#44b37f',idle: '#faa51b',offline: '#747f8d',dnd: '#f04848'}
         if (!level_db.tiene(member.id)) {
      await level_db.establecer(member.id, {xp: 0, nivel: 1})
     }
    
    console.log(true)
    
    
    let { nivel, xp } = await level_db.obtener(`${member.id}`);
    //const x1= 42, y1=62, radius1 = 120, height1= 934, width1 = 282
    const x1= 54, y1=62, radius1 = 83, height1= 934, width1 = 282
    

    let subirlvl = 5 * nivel ** 2 + 50 * nivel + 100;
    let colorxd = await color.obtener(`${member.id}`)
    let skere = `${xp}/${subirlvl}`;
    const canvas = createCanvas(934, 282);
    const ctx = canvas.getContext("2d");
 //const background = await loadImage("https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQn2KyjHTGzHB6yIUUb_7UQHtktiFkuat4e89TfP61oUD21N205&usqp=CAU");    ctx.drawImage(background, 0, 0, canvas.width, canvas.height);
 const background = await loadImage("https://cdn.discordapp.com/attachments/680568391404093457/719679016247754802/cardxd.png");  
        ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

      roundRect(ctx, 300, 190, 500, 28, 18, false,'#bababa', true,'#00000') //BORDE
      roundRect(ctx, 300, 190, 500, 28, 18, true,'#494747', true,'#494747') //FONDO
    
    ctx.save();
    ctx.beginPath();
          roundRect(ctx, 300, 190, 500, 28, 18, false,'#494747', true,'#494747') //FONDO
ctx.closePath();
        ctx.clip()
      roundRect(ctx, 300, 190, xp / subirlvl * 500, 28, 18, true, colorxd, false) //RELLENO XP
ctx.restore()

    //FIn

    function roundRect(ctx, x, y, width, height, radius, fill, colorfill, stroke, colorstroke) {
      if (typeof stroke == 'undefined') stroke = true
      if (typeof radius === 'undefined') radius = 5
      if (typeof radius === 'number') {

      radius = {tl: radius, tr: radius, br: radius, bl: radius}
     } else {
      var defaultRadius = {tl: 0, tr: 0, br: 0, bl: 0}
      for (var side in defaultRadius) {
        radius[side] = radius[side] || defaultRadius[side]
      }
     }
      ctx.beginPath()
      ctx.moveTo(x + radius.tl, y)
      ctx.lineTo(x + width - radius.tr, y)
      ctx.quadraticCurveTo(x + width, y, x + width, y + radius.tr)
      ctx.lineTo(x + width, y + height - radius.br)
      ctx.quadraticCurveTo(x + width, y + height, x + width - radius.br, y + height)
      ctx.lineTo(x + radius.bl, y + height)
      ctx.quadraticCurveTo(x, y + height, x, y + height - radius.bl)
      ctx.lineTo(x, y + radius.tl)
      ctx.quadraticCurveTo(x, y, x + radius.tl, y)
      ctx.closePath()
      if (fill) {
        ctx.fillStyle = colorfill
        ctx.fill()
      }
      if (stroke) {
        ctx.strokeStyle  = colorstroke
        ctx.lineWidth = 2
        ctx.stroke()
      
    }}

//     ctx.beginPath();
//     ctx.lineWidth = 4;
//     ctx.strokeStyle = "#000000";
//     ctx.globalAlpha = 1;
//     ctx.fillStyle = "#363535";
//     // ctx.fillRect(180, 216, 770, 65);
//     ctx.fillRect(250, 160, 600, 65);
//     ctx.fill();
//     ctx.globalAlpha = 1;
//     ctx.strokeRect(250, 160, 600, 65);
//     ctx.stroke();

//     ctx.fillStyle = colorxd;
//     ctx.globalAlpha = 0.6;
//     ctx.fillRect(250, 160, ((100 / (subirlvl)) * xp) * 6, 65);    
//     ctx.fill();
//     ctx.globalAlpha = 1;
//     ctx.font = "35px Impact";
//     ctx.textAlign = "center";
//     ctx.fillStyle = "#ffffff";
//     ctx.fillText(`${xp} / ${subirlvl} XP`, 567, 205);
    
    ctx.fillStyle = "#ffffff";
    ctx.font = "30px Impact";//Impact
    ctx.textAlign = "left";
    ctx.fillText(member.user.tag, 300, 160);

    ctx.font = "30px Impact";
    ctx.fillStyle = "#2d84eb";
    ctx.fillText(" LEVEL:", 650, 90);

    //ctx.font = "1px Impact";
    //ctx.fillStyle = "#2bedef";
    //ctx.fillText(" XP:", 800, 170);
    
    ctx.font = "30px Impact";
    ctx.fillStyle = "#2d84eb";
    ctx.fillText("XP:", 315, 93);
    
    ctx.font = "20px Impact";
    ctx.fillStyle = "#ffffff";
    ctx.fillText(skere, 380, 90);
    
    ctx.font = "50px Impact";
    ctx.fillStyle = "#ffffff";
    ctx.fillText(nivel, 790, 90);


    ctx.beginPath()
    ctx.arc(137, 145, 86, 0, Math.PI * 2, true);
    ctx.lineWidth = 7;
    ctx.strokeStyle = estado[member.presence.status]
    ctx.stroke();
    ctx.closePath();  
    // ctx.clip();
    // const avatar = await loadImage(member.user.displayAvatarURL);
    // ctx.drawImage(avatar, 40, 40, 250, 250);
    
  ctx.save()
  ctx.beginPath()
  ctx.arc(x1+radius1, y1+radius1, radius1, 0, Math.PI*2, true)
  ctx.closePath()
  ctx.clip()

  const avatar = await loadImage(member.user.displayAvatarURL({format: "png"}));
  ctx.drawImage(avatar, x1, y1, radius1*2, radius1*2)
  ctx.restore()
    
  // ctx.beginPath()
  // ctx.arc(70, 240, 22, 0, Math.PI*2, true)
  // ctx.closePath()
  // ctx.fillStyle= estado[member.presence.status]
  // ctx.fill()
  // ctx.lineWidth=4
  // ctx.stroke()



    const attachment = new MessageAttachment(canvas.toBuffer(), "rank.png");
    message.channel.send(attachment);
  }
};
