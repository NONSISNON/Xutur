module.exports = { 
    config: {
nombre: "bal-global",
alias: []
    },
  run: async (client, message, args, lang) => {   

const Discord = require("discord.js") 
const db = require('megadb') 
const balance = new db.crearDB('balance', 'level')
const color = new db.crearDB('color', 'level')



  
    
    let usuario = message.author
    let bal = await balance.obtener(`${usuario.id}`)
    let colorxd = await color.obtener(`${usuario.id}`)




const embed = new Discord.MessageEmbed()
  .setDescription("Actualmente tienes un saldo de **"+bal+"** monedas <:Coin:660424723854786584>")
  .setColor(colorxd)
  message.channel.send({embed})

}
      
  }